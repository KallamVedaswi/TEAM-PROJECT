// image size for tmdb

export const img_300 = 'https://image.tmdb.org/t/p/w300';


export const img_not_available = 'https://www.movienewz.com/img/films/poster-holder.jpg';

export const no_picture = 'https://dummyimage.com/300x450/ff5860/000&text=Photo Not Available'