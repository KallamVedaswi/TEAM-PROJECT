
import RouteComponent from './Route';

function App() {
  return (
    <div className="App">
      <RouteComponent />
    </div>
  );
}

export default App;
